# Time Tracker (Postgres-backed)

Same design as before, now saving to a real Postgres database instead of
browser/artifact storage — so your entries survive refreshes, new devices,
and new browser sessions.

## 1. Create a free Postgres database on Vercel

1. In your Vercel dashboard: **Storage** → **Create Database** → choose
   **Postgres** (Neon-backed, has a free tier).
2. Once created, open the database's **.env.local** tab and copy the
   `DATABASE_URL` value (or `POSTGRES_URL` — either works, see step 3).

## 2. Local setup

```bash
npm install
cp .env.example .env.local
# paste your real connection string into .env.local as DATABASE_URL=...
npm run dev
```

Visit http://localhost:3000 — the app will automatically create the
`entries` table on its first request (see `lib/db.js`), so you don't need
to run `schema.sql` manually unless you want to.

## 3. Connect the database to your Vercel project

In your Vercel project settings → **Environment Variables**, add:

```
DATABASE_URL = <your connection string>
```

If Vercel's Postgres integration only gives you `POSTGRES_URL` (not
`DATABASE_URL`), just add a second env var named `DATABASE_URL` with the
same value — the code specifically reads `process.env.DATABASE_URL`.

## 4. Deploy

```bash
npm i -g vercel   # if you don't have it
vercel
```

Or connect the repo in the Vercel dashboard and click Deploy.

## What changed vs. the original version

- Storage moved from the artifact's in-browser storage to a Postgres
  table (`entries`), via two API routes:
  - `GET/POST /api/entries`
  - `PUT/DELETE /api/entries/[id]`
- Each add/edit/delete now writes directly to its own database row,
  instead of overwriting one big JSON blob — this removes the
  race-condition class of bug entirely (no "save the whole array before
  it's loaded" risk anymore).
- Visual design, layout, VAT logic, and CSV/text export are unchanged.
