import { getPool, ensureSchema, rowToEntry } from '../../../lib/db';

export default async function handler(req, res) {
  const { id } = req.query;

  try {
    await ensureSchema();
    const pool = getPool();

    if (req.method === 'PUT') {
      const e = req.body;
      if (!e || !e.date || !e.desc) {
        return res.status(400).json({ error: 'date and desc are required' });
      }
      const { rows } = await pool.query(
        `UPDATE entries SET
           date = $1, client = $2, type = $3, hours = $4, amount = $5,
           vat_applies = $6, vat_rate = $7, vat_amount = $8, total = $9, description = $10
         WHERE id = $11
         RETURNING *`,
        [
          e.date, e.client || '', e.type || 'custom', e.hours ?? null, e.amount ?? 0,
          e.vatApplies ?? true, e.vatRate ?? 18, e.vatAmount ?? 0, e.total ?? (e.amount ?? 0),
          e.desc || '', id,
        ]
      );
      if (rows.length === 0) return res.status(404).json({ error: 'Entry not found' });
      return res.status(200).json(rowToEntry(rows[0]));
    }

    if (req.method === 'DELETE') {
      const { rowCount } = await pool.query('DELETE FROM entries WHERE id = $1', [id]);
      if (rowCount === 0) return res.status(404).json({ error: 'Entry not found' });
      return res.status(204).end();
    }

    res.setHeader('Allow', ['PUT', 'DELETE']);
    return res.status(405).json({ error: `Method ${req.method} not allowed` });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Database error', detail: String(err.message || err) });
  }
}
