import { getPool, ensureSchema, rowToEntry } from '../../../lib/db';

export default async function handler(req, res) {
  try {
    await ensureSchema();
    const pool = getPool();

    if (req.method === 'GET') {
      const { rows } = await pool.query('SELECT * FROM entries ORDER BY date ASC, created_at ASC');
      return res.status(200).json(rows.map(rowToEntry));
    }

    if (req.method === 'POST') {
      const e = req.body;
      if (!e || !e.date || !e.desc) {
        return res.status(400).json({ error: 'date and desc are required' });
      }
      const id = e.id || (Date.now().toString(36) + Math.random().toString(36).slice(2, 8));
      const { rows } = await pool.query(
        `INSERT INTO entries (id, date, client, type, hours, amount, vat_applies, vat_rate, vat_amount, total, description)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
         RETURNING *`,
        [
          id, e.date, e.client || '', e.type || 'custom',
          e.hours ?? null, e.amount ?? 0, e.vatApplies ?? true,
          e.vatRate ?? 18, e.vatAmount ?? 0, e.total ?? (e.amount ?? 0),
          e.desc || '',
        ]
      );
      return res.status(201).json(rowToEntry(rows[0]));
    }

    res.setHeader('Allow', ['GET', 'POST']);
    return res.status(405).json({ error: `Method ${req.method} not allowed` });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Database error', detail: String(err.message || err) });
  }
}
