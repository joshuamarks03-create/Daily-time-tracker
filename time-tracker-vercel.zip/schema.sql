-- Run this once against your Postgres database (the app also runs it
-- automatically on first API call, so this is optional/for reference).

CREATE TABLE IF NOT EXISTS entries (
  id TEXT PRIMARY KEY,
  date DATE NOT NULL,
  client TEXT DEFAULT '',
  type TEXT NOT NULL DEFAULT 'custom',
  hours NUMERIC,
  amount NUMERIC NOT NULL DEFAULT 0,
  vat_applies BOOLEAN NOT NULL DEFAULT true,
  vat_rate NUMERIC NOT NULL DEFAULT 18,
  vat_amount NUMERIC NOT NULL DEFAULT 0,
  total NUMERIC NOT NULL DEFAULT 0,
  description TEXT DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
